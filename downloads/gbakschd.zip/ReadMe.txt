GBAK Scheduler 1.0 for Interbase

GBAK Scheduler is FREEWARE



OVERVIEW
--------

GBAK Scheduler is an Interbase utility that performs 
regular database backups with a user defined strategy. 
The main feature is to preserve a required number of 
backups to allow data recovery for previous days. 

GBAK Scheduler keeps several backups on your disks 
(for example 4 a day for 30 days) so you can solve your 
possible database problem with the preferred copy (not 
always the last).

GBAK Scheduler is safe because it doesn't perform backup 
itself, but runs your copy of GBAK.EXE.

GBAK Scheduler uses few system resources and can run as an 
application or a Windows NT service. It can run in automatic 
(loaded and started at startup) or manual mode and can run 
your backup tasks whenever you want with the Execute now! 
command, without waiting for the scheduled time.

Main features

Mirror: Creates double copies of your backups on different 
disks/computers for extra protection against disk crashes.


Zip compression: Compress your backup file with industrial 
standard Zip format to save disks space.

Priority selection: GBAK Scheduler ca run GBAK.EXE in Idle, 
Normal or High priority.

Log information: Creates a simple or detailed log file to 
supervise backup tasks.

E-mail notification: Sends log information directly on your 
remote workstation.

Backup strategy: With GBAK Scheduler you can select your 
preferred backup rotation scheme or choose Smart set to keep 
last 6 months backups on line.



SYSTEM REQUIREMENTS
-------------------

To use GBAK Scheduler, you must have Windows 95 or 
Windows NT 4.0 and, obviously, Interbase.

The copy of GBAK installed by Local Interbase doesn�t perform 
remote backups. Use Interbase workgroup server or Interbase 
developer client instead.

For e-mail notification you must have a TCP/IP connection and 
a mail account with an ISP (Internet Service Provider) or an 
Internet-style network, providing an SMTP service.

GBAK Scheduler was developed and tested on Windows 95 
(4.00.950a) and Windows NT 4.0 (sp3).



INSTALLATION
------------

This is the content of the distribution archive GBAKSchd.zip:

GBAKSchd.exe	        Main program for either Windows 95 and NT 4.0
GBAKSchd.hlp		On line help
GBAKSrvc.exe		Windows NT service
ZipDll.dll		Info-Zip compression library
ReadMe.txt		ReadMe file
License.txt		License file
File_id.diz		Standard BBS Diz file

To install GBAK Scheduler simply extract all files in this 
archive to a directory (you must have read/write permissions 
over the installation directory). Then you can start the 
application running GBAKSchd.exe.

GBAK Scheduler doesn�t install any files in the system directory 
and modifies the registry only in two circumstances:

If you run the program over Windows 95 and select the automatic 
startup option , GBAK Scheduler inserts the value 
GBAKSchd=application_path in the key:

HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run.

If you run the program over Windows NT 4.0 and select the service 
startup option, GBAK Scheduler installs the service and Windows NT 
creates some entry in the HKEY_LOCAL_MACHINE key to update the 
Windows service manager.

For installation of the service (Windows NT 4.0 only) you can both 
run GBAKSrvc.exe /install or select the service startup options 
from the main program (recommended).
To remove the service (Windows NT 4.0 only) from the Windows service 
manager you can both run GBAKSrvc.exe /remove or select the 
application startup options from the main program (recommended).



UNINSTALLATION
--------------

To uninstall GBAK Scheduler you must first select the application 
startup - manual mode option from the main program and then remove 
the entire GBAK Scheduler directory. With this procedure you are sure 
that all the registry entries of GBAK Scheduler will be removed.

If you don�t set the application startup - manual mode option from 
the main program before deleting the installation directory, some 
entries of the registry could persist.



TECHNICAL SUPPORT
-----------------

I will handle support issues with who uses this package on a 
time-available basis.
Since this is being distributed as freeware, you can't expect the kind 
of support you'd get from a commercial vendor.
Please limit your questions to those that directly pertain to this 
package.

Future updates to this software will be announced on Interbase related 
newsgroups and mailing lists. 

Please DO NOT ask me to e-mail you when this software is updated.

If you have suggestions, complaints or bug reports, please contact 

Mauro Barbieri
gbakschd@geocities.com
http://www.geocities.com/SiliconValley/Bay/9603





Interbase is a registered trademark of Borland International.
Windows 95 and Windows NT are registered trademarks of the Microsoft 
Corporation.
All other trademarks and service marks are the property of their 
respective owners.

Many thanks to the Info-Zip group for the freeware ZipDll compression 
library.

http://www.cdrom.com/pub/infozip/

